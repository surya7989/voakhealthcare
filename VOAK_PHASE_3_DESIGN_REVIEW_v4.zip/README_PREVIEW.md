# Voak Health Care — Phase 3 V4 UI/UX Design System Review Package
## Reconciled Master Visual Prototype & Evidence Package (V4 Final Correction Gate)

**Package:** `VOAK_PHASE_3_DESIGN_REVIEW_v4.zip`  
**Phase:** Phase 3 of 31 — Professional UI/UX Design (V4 Reconciled Acceptance Baseline)  
**Date:** October 18, 2026  
**Status:** PHASE 3 AUDITED & RECONCILED — STRICT PHASE GATE HALT (PHASE 4 NOT AUTHORIZED)  
**Total Scope:** Exactly 32 Phases (Phase 0 through Phase 31)

---

### 1. How to Run & Preview the Prototype

You can inspect the prototype in either of two ways:

#### Option A: Lightweight Local HTTP Server (Recommended)
1. Ensure Node.js is installed.
2. Open a terminal in this extracted directory.
3. Run:
   ```bash
   node serve.js
   ```
4. Open your web browser and navigate to:
   ```
   http://127.0.0.1:4173/
   ```

#### Option B: Direct Browser Inspection
- Simply double-click `index.html` in your file explorer to open it directly in Google Chrome, Microsoft Edge, Mozilla Firefox, or Apple Safari. All styles, fonts, and scripts will load immediately.

---

### 2. Prototype Features & Key Inspection Views

Use the top preview navigation toolbar inside the prototype to switch between master views:

1. **Desktop Homepage (`#hero`):**
   - Lavender hero composition (`#F2F0F8`) with clinician portrait framed in pastel shapes.
   - White rounded main page shell (`border-radius: 36px`).
   - Editorial serif headlines (`Fraunces`, `#252B5E`).
   - Three colorful feature cards (Pink, Yellow, Mint).
   - 8-tile asymmetric services grid.
   - All unverified business claims, partner names, and regulatory assertions sanitized or badged as `[CONTENT PENDING APPROVAL]`.

2. **Mobile Homepage (`#mobile`):**
   - Single-column responsive composition verified across 320px, 360px, 390px, and 428px.
   - Exact 0px horizontal overflow across all mobile viewports.

3. **All 22 Public Pages (`#pages`):**
   - Reconciled canonical requirement IDs (`PUB-01` mapped to `FR-PUB-002`, `PUB-10` mapped to `FR-PUB-004`, `PUB-20` & `PUB-21` mapped to `FR-PUB-022`).
   - Preserves all 22 public pages including `PAGE-PUB-10 — Partners & Clients`, `/request-proposal`, and `/faqs`.
   - Click **"Inspect Screen →"** on any page card to launch the **Full-Page Screen Inspector**, rendering a complete, full-scale high-fidelity mockup with page-specific hero, body sections, cards, and footer.

4. **All 19 Admin Modules (`#admin`):**
   - Deep slate-navy sidebar (`#0F172A`) containing all 19 canonical modules (`ADM-01` to `ADM-19`).
   - **Least-Privilege RBAC Simulator:** Switch between the 5 canonical roles (`Super Admin`, `Website Admin`, `Content Editor`, `BD Manager`, `HR Manager`). Unauthorized module access triggers a **SIMULATED 403 ACCESS DENIED** card.
   - All records watermarked `[DEMO DATA ONLY — SIMULATED RECORDS]`.
   - Admin UI labeled as a **Proposed Design Concept (Not Approved)** awaiting explicit client authorization.

5. **Component & Design Token System (`#components`):**
   - Design tokens, color swatches with contrast ratios, typography scale, buttons, badges, chips, and input fields.

6. **Approved References Comparison (`#refs`):**
   - HealthOnUs branding has been removed from the comparison.
   - Voak Admin Console is explicitly marked as *Proposed Design Concept (Not Approved)*.
   - Approved Image 2 benchmark slot indicates pending placement of the authentic user file at `design/phase-03/references/approved_homepage_reference_image_2.png`.

7. **Interactive Proposal Wizard Modal (FORM-PUB-03):**
   - Click "Request Proposal" from any header or card to launch the 4-step RFP wizard.

---

### 3. Package File Structure & Screenshot Inventory

The archive contains exactly the following files:

```
VOAK_PHASE_3_DESIGN_REVIEW_v4/
├── index.html                                        # Master navigable visual prototype shell
├── styles.css                                        # Master design tokens & stylesheet
├── app.js                                            # Prototype logic (22 public mockups, 19 admin modules, role simulator)
├── serve.js                                          # Local HTTP preview server (port 4173)
├── README_PREVIEW.md                                 # This preview guide and file manifest
├── assets/
│   └── images/
│       ├── hero_doctor.jpg                           # High-res healthcare professional portrait
│       └── operations_manager.jpg                    # Clinical operations coordinator portrait
├── references/
│   ├── approved_homepage_reference_image_2.png       # Homepage reference slot (Awaiting user original)
│   └── approved_admin_reference_portal.png            # Legacy admin reference (Labeled: Proposed Concept / Third-Party)
├── screenshots/
│   ├── 01_desktop_homepage.png                       # Clean Desktop Homepage (1440 × 5205 px)
│   ├── 02_mobile_homepage_390px.png                  # Clean Mobile Homepage (390 × 1742 px)
│   ├── 03_tablet_homepage_768px.png                  # Clean Tablet Homepage (768 × 9097 px)
│   ├── 04_public_pages_gallery.png                   # Clean Public Pages Gallery (1440 × 3510 px)
│   ├── 05_admin_dashboard.png                        # Active ADM-01 Admin Dashboard (1440 × 1217 px)
│   ├── 06_component_system.png                       # Component Design Token System (1440 × 2096 px)
│   ├── 07_approved_reference_comparison.png          # Reference Comparison View (1440 × 920 px)
│   ├── 08_proposal_wizard_modal.png                  # Clean RFP Wizard Modal (1440 × 960 px)
│   ├── 09_simulated_403_access_denied.png            # Clean Simulated 403 State (1440 × 1200 px)
│   ├── admin_modules/                                # 19 Active Admin Module Workspace Captures:
│   │   ├── admin_adm-01_preview.png                  # ADM-01 Executive Dashboard (1440 × 1217 px)
│   │   ├── admin_adm-02_preview.png                  # ADM-02 Authentication & MFA (1440 × 1217 px)
│   │   ├── admin_adm-03_preview.png                  # ADM-03 Users & RBAC Matrix (1440 × 1217 px)
│   │   ├── admin_adm-04_preview.png                  # ADM-04 Static Pages CMS (1440 × 1217 px)
│   │   ├── admin_adm-05_preview.png                  # ADM-05 Homepage Layout Config (1440 × 1217 px)
│   │   ├── admin_adm-06_preview.png                  # ADM-06 Services Management CMS (1440 × 1217 px)
│   │   ├── admin_adm-07_preview.png                  # ADM-07 Industries Verticals (1440 × 1217 px)
│   │   ├── admin_adm-08_preview.png                  # ADM-08 Media Asset Library (1440 × 1217 px)
│   │   ├── admin_adm-09_preview.png                  # ADM-09 Contact Inquiries CRM (1440 × 1217 px)
│   │   ├── admin_adm-10_preview.png                  # ADM-10 Strategic Partnerships (1440 × 1217 px)
│   │   ├── admin_adm-11_preview.png                  # ADM-11 Proposal / RFP Desk (1440 × 1217 px)
│   │   ├── admin_adm-12_preview.png                  # ADM-12 Email Templates Outbox (1440 × 1217 px)
│   │   ├── admin_adm-13_preview.png                  # ADM-13 Careers Job Postings (1440 × 1217 px)
│   │   ├── admin_adm-14_preview.png                  # ADM-14 Candidate Resumes Vault (1440 × 1217 px)
│   │   ├── admin_adm-15_preview.png                  # ADM-15 Case Studies CMS (1440 × 1217 px)
│   │   ├── admin_adm-16_preview.png                  # ADM-16 Insights & Articles CMS (1440 × 1217 px)
│   │   ├── admin_adm-17_preview.png                  # ADM-17 SEO Console & Redirects (1440 × 1217 px)
│   │   ├── admin_adm-18_preview.png                  # ADM-18 System Settings & Entity (1440 × 1217 px)
│   │   └── admin_adm-19_preview.png                  # ADM-19 Audit Logs & Telemetry (1440 × 1217 px)
│   └── public_pages/                                 # 22 Standalone Public Page Captures:
│       ├── page_pub-01_preview.png                   # PUB-01 Home (1440 × 3462 px)
│       ├── page_pub-02_preview.png                   # PUB-02 About Us (1440 × 2520 px)
│       ├── page_pub-03_preview.png                   # PUB-03 Services Catalog (1440 × 2061 px)
│       ├── page_pub-04_preview.png                   # PUB-04 Service Detail (1440 × 1804 px)
│       ├── page_pub-05_preview.png                   # PUB-05 Industries (1440 × 2142 px)
│       ├── page_pub-06_preview.png                   # PUB-06 Industry Detail (1440 × 1775 px)
│       ├── page_pub-07_preview.png                   # PUB-07 Why Choose Voak (1440 × 2047 px)
│       ├── page_pub-08_preview.png                   # PUB-08 How We Work (1440 × 2233 px)
│       ├── page_pub-09_preview.png                   # PUB-09 Quality & Compliance (1440 × 1831 px)
│       ├── page_pub-10_preview.png                   # PUB-10 Partners & Clients (1440 × 1991 px)
│       ├── page_pub-11_preview.png                   # PUB-11 Case Studies (1440 × 2055 px)
│       ├── page_pub-12_preview.png                   # PUB-12 Careers Hub (1440 × 2058 px)
│       ├── page_pub-13_preview.png                   # PUB-13 Job Detail & App (1440 × 1940 px)
│       ├── page_pub-14_preview.png                   # PUB-14 Insights & Articles (1440 × 2011 px)
│       ├── page_pub-15_preview.png                   # PUB-15 Article Detail (1440 × 2236 px)
│       ├── page_pub-16_preview.png                   # PUB-16 FAQs (1440 × 2168 px)
│       ├── page_pub-17_preview.png                   # PUB-17 Contact Us (1440 × 2095 px)
│       ├── page_pub-18_preview.png                   # PUB-18 Partner With Us (1440 × 2035 px)
│       ├── page_pub-19_preview.png                   # PUB-19 Request a Proposal (1440 × 1687 px)
│       ├── page_pub-20_preview.png                   # PUB-20 Privacy Policy (1440 × 1914 px)
│       ├── page_pub-21_preview.png                   # PUB-21 Terms & Conditions (1440 × 1718 px)
│       └── page_pub-22_preview.png                   # PUB-22 Error States 404/500 (1440 × 1616 px)
└── docs/
    └── 20_FINAL_VISUAL_EVIDENCE_VERIFICATION.md      # Full verification report with telemetry
```

---

### 4. Governance & Roadmap Boundary Status

- **Phase 0:** ACCEPTED
- **Phase 1:** ACCEPTED
- **Phase 2:** ACCEPTED
- **Phase 3:** AUDITED, RECONCILED & HALTED (Under client review)
- **Phase 4:** STRICTLY NOT AUTHORIZED (Halted before start)
- **Total Roadmap Scope:** Exactly 32 phases (Phase 0 through Phase 31) strictly preserved.
