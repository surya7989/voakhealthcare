/**
 * Voak Health Care — Phase 3 Responsive Breakpoint Overflow Automated Verification
 * Reproducible automated test across 9 canonical viewport widths:
 * 320px, 360px, 390px, 428px, 768px, 1024px, 1280px, 1440px, 1920px.
 */

const { spawn } = require('child_process');
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 4174;
const ROOT = path.join(__dirname, '..', 'design', 'phase-03');

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml'
};

const BREAKPOINTS = [
  { width: 320, height: 568, category: 'Compact Mobile (iPhone SE)' },
  { width: 360, height: 800, category: 'Standard Android Compact' },
  { width: 390, height: 844, category: 'Modern iPhone Baseline (iPhone 12/13/14)' },
  { width: 428, height: 926, category: 'Large Mobile Phablet (iPhone Pro Max)' },
  { width: 768, height: 1024, category: 'Tablet Portrait (iPad Mini / Air)' },
  { width: 1024, height: 768, category: 'Tablet Landscape / Small Laptop' },
  { width: 1280, height: 800, category: 'Standard HD Laptop / Desktop' },
  { width: 1440, height: 900, category: 'Approved Target Desktop Benchmark' },
  { width: 1920, height: 1080, category: 'Full HD Ultrawide Desktop' }
];

const server = http.createServer((req, res) => {
  let reqPath = decodeURI(req.url.split('?')[0]);
  if (reqPath === '/') reqPath = '/index.html';
  const filePath = path.join(ROOT, reqPath);
  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    res.writeHead(404); res.end(); return;
  }
  const ext = path.extname(filePath).toLowerCase();
  res.writeHead(200, { 'Content-Type': MIME_TYPES[ext] || 'application/octet-stream' });
  fs.createReadStream(filePath).pipe(res);
});

server.listen(PORT, '127.0.0.1', async () => {
  console.log(`Responsive Test Server listening on http://127.0.0.1:${PORT}`);
  await runTest();
});

async function runTest() {
  const edgePath = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
  const userDataDir = path.join(__dirname, '..', 'scratch', 'edge-test-overflow');

  const edgeProcess = spawn(edgePath, [
    '--headless=new',
    '--remote-debugging-port=9227',
    '--disable-gpu',
    '--no-first-run',
    '--no-default-browser-check',
    `--user-data-dir=${userDataDir}`,
    'about:blank'
  ]);

  await new Promise(r => setTimeout(r, 1500));

  try {
    const targets = await new Promise((res, rej) => {
      http.get('http://127.0.0.1:9227/json/list', r => {
        let d = ''; r.on('data', c => d += c); r.on('end', () => res(JSON.parse(d)));
      }).on('error', rej);
    });
    const wsUrl = (targets.find(t => t.type === 'page') || targets[0]).webSocketDebuggerUrl;

    const ws = new WebSocket(wsUrl);
    let id = 1;
    const send = (method, params = {}) => new Promise((resolve, reject) => {
      const curId = id++;
      const handler = evt => {
        const msg = JSON.parse(evt.data);
        if (msg.id === curId) {
          ws.removeEventListener('message', handler);
          if (msg.error) reject(new Error(msg.error.message));
          else resolve(msg.result);
        }
      };
      ws.addEventListener('message', handler);
      ws.send(JSON.stringify({ id: curId, method, params }));
    });

    await new Promise(r => ws.onopen = r);
    await send('Page.enable');
    await send('Runtime.enable');
    await send('DOM.enable');

    await send('Page.navigate', { url: `http://127.0.0.1:${PORT}/index.html` });
    await new Promise(r => setTimeout(r, 2000));

    console.log('\n========================================================================================');
    console.log('VOAK HEALTH CARE — PHASE 3 AUTOMATED RESPONSIVE OVERFLOW SWEEP RESULTS');
    console.log('========================================================================================\n');

    const results = [];

    for (const bp of BREAKPOINTS) {
      await send('Emulation.setDeviceMetricsOverride', {
        width: bp.width,
        height: bp.height,
        deviceScaleFactor: 1,
        mobile: bp.width < 768
      });
      await new Promise(r => setTimeout(r, 350));

      const evalResult = await send('Runtime.evaluate', {
        expression: `(() => {
          const docEl = document.documentElement;
          const body = document.body;
          const scrollW = Math.max(docEl.scrollWidth, body.scrollWidth);
          const innerW = window.innerWidth;
          const clientW = docEl.clientWidth;
          const overflowX = scrollW - innerW;

          // Find any overflowing elements
          const elements = document.querySelectorAll('*');
          let offendingSelector = null;
          let maxRight = innerW;

          for (let el of elements) {
            const rect = el.getBoundingClientRect();
            if (rect.right > maxRight + 1) {
              offendingSelector = el.tagName + (el.className ? '.' + String(el.className).trim().split(' ').join('.') : '') + (el.id ? '#' + el.id : '');
              maxRight = rect.right;
            }
          }

          return {
            windowInnerW: innerW,
            docScrollW: scrollW,
            clientW: clientW,
            overflowPx: Math.max(0, overflowX),
            offendingElement: offendingSelector,
            passed: overflowX <= 1
          };
        })()`,
        returnByValue: true
      });

      const resVal = evalResult.result.value;
      const pass = resVal.passed;

      results.push({
        width: bp.width,
        height: bp.height,
        category: bp.category,
        windowWidth: resVal.windowInnerW,
        scrollWidth: resVal.docScrollW,
        overflowPx: resVal.overflowPx,
        status: pass ? 'PASS' : 'FAIL',
        offendingElement: resVal.offendingElement
      });

      console.log(`[${bp.width}px × ${bp.height}px] ${bp.category.padEnd(35)} | Window: ${String(resVal.windowInnerW).padStart(4)}px | Scroll: ${String(resVal.docScrollW).padStart(4)}px | Overflow: ${String(resVal.overflowPx).padStart(2)}px | Status: ${pass ? 'PASS' : 'FAIL'}`);
    }

    // Save results to tests/responsive_test_results.json
    fs.writeFileSync(path.join(__dirname, 'responsive_test_results.json'), JSON.stringify(results, null, 2));

    console.log('\n========================================================================================');
    console.log(`Summary: ${results.filter(r => r.status === 'PASS').length} of ${results.length} breakpoints passed zero-overflow validation.`);
    console.log('Results written to tests/responsive_test_results.json');
    console.log('========================================================================================\n');

    ws.close();
    edgeProcess.kill();
    server.close();
    process.exit(0);
  } catch (err) {
    console.error('Error during responsive overflow test:', err);
    edgeProcess.kill();
    server.close();
    process.exit(1);
  }
}
