/**
 * Voak Health Care — Phase 3 Expanded Responsive Automated Verification Suite
 * Exercises:
 *  - All 22 Public Page Layouts at 9 Canonical Viewport Widths (198 tests)
 *  - All 19 Admin Module Workspaces at 3 Representative Viewport Widths (57 tests)
 * Total: 255 Distinct Automated Layout Verifications
 *
 * Records: screen identifier, route, viewport, marker verification, innerWidth, scrollWidth,
 * overflow detection, console errors, and PASS/FAIL result.
 * Outputs to tests/results/phase-03-responsive-results.json and tests/results/phase-03-test-output.txt.
 */

const { spawn } = require('child_process');
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 4192;
const DEBUG_PORT = 9249;

// 1. Resolve project root
const candidateRoots = [
  path.join(__dirname, '..'),                       // Extracted archive layout
  path.join(__dirname, '..', 'design', 'phase-03'),  // Workspace repository layout
];

const ROOT = candidateRoots.find(p => fs.existsSync(path.join(p, 'index.html')));
if (!ROOT) {
  console.error('FATAL: Could not locate index.html in candidate roots:', candidateRoots);
  process.exit(1);
}
console.log('Serving verified prototype root from:', ROOT);

// 2. Resolve browser
const candidateBrowsers = [
  process.env.BROWSER_PATH,
  process.env.EDGE_PATH,
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  process.env.CHROME_PATH,
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
].filter(Boolean);

const browserPath = candidateBrowsers.find(p => fs.existsSync(p));
if (!browserPath) {
  console.error('FATAL: No compatible Chromium browser found.');
  process.exit(1);
}
console.log('Using browser executable:', browserPath);

const RESULTS_DIR = path.join(__dirname, 'results');
if (!fs.existsSync(RESULTS_DIR)) fs.mkdirSync(RESULTS_DIR, { recursive: true });

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml'
};

const PUBLIC_BREAKPOINTS = [
  { width: 320, height: 568, category: 'Compact Mobile (iPhone SE)' },
  { width: 360, height: 800, category: 'Standard Android Compact' },
  { width: 390, height: 844, category: 'Modern iPhone Baseline (iPhone 12/13/14)' },
  { width: 428, height: 926, category: 'Large Mobile Phablet (iPhone Pro Max)' },
  { width: 768, height: 1024, category: 'Tablet Portrait (iPad Mini / Air)' },
  { width: 1024, height: 768, category: 'Tablet Landscape / Small Laptop' },
  { width: 1280, height: 800, category: 'Standard HD Laptop / Desktop' },
  { width: 1440, height: 900, category: 'Approved Target Desktop Benchmark' },
  { width: 1920, height: 1080, category: 'Full HD Ultrawide Desktop' }
];

const ADMIN_BREAKPOINTS = [
  { width: 390, height: 844, category: 'Mobile Admin' },
  { width: 768, height: 1024, category: 'Tablet Admin' },
  { width: 1440, height: 900, category: 'Desktop Admin' }
];

const server = http.createServer((req, res) => {
  let reqPath = decodeURI(req.url.split('?')[0]);
  if (reqPath === '/') reqPath = '/index.html';
  const filePath = path.join(ROOT, reqPath);
  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    res.writeHead(404); res.end(); return;
  }
  const ext = path.extname(filePath).toLowerCase();
  res.writeHead(200, { 'Content-Type': MIME_TYPES[ext] || 'application/octet-stream' });
  fs.createReadStream(filePath).pipe(res);
});

server.listen(PORT, '127.0.0.1', async () => {
  console.log(`Expanded Responsive Test Server running on http://127.0.0.1:${PORT}`);
  await runTests();
});

async function runTests() {
  const userDataDir = path.join(__dirname, '..', 'scratch', 'edge-test-expanded');
  if (!fs.existsSync(userDataDir)) fs.mkdirSync(userDataDir, { recursive: true });

  const browserProcess = spawn(browserPath, [
    '--headless=new',
    `--remote-debugging-port=${DEBUG_PORT}`,
    '--disable-gpu',
    '--no-first-run',
    '--no-default-browser-check',
    `--user-data-dir=${userDataDir}`,
    'about:blank'
  ]);

  let targets = null;
  for (let attempt = 0; attempt < 25; attempt++) {
    await new Promise(r => setTimeout(r, 400));
    try {
      targets = await new Promise((res, rej) => {
        const req = http.get(`http://127.0.0.1:${DEBUG_PORT}/json/list`, r => {
          let d = ''; r.on('data', c => d += c); r.on('end', () => res(JSON.parse(d)));
        });
        req.on('error', rej);
        req.setTimeout(1000, () => req.destroy(new Error('timeout')));
      });
      if (targets && targets.length > 0) break;
    } catch(e) {}
  }

  if (!targets || targets.length === 0) {
    browserProcess.kill(); server.close();
    throw new Error(`Failed to connect to browser on port ${DEBUG_PORT}`);
  }

  const outputLog = [];
  function log(msg) {
    console.log(msg);
    outputLog.push(msg);
  }

  try {
    const wsUrl = (targets.find(t => t.type === 'page') || targets[0]).webSocketDebuggerUrl;
    const ws = new WebSocket(wsUrl);
    let id = 1;
    const send = (method, params = {}) => new Promise((resolve, reject) => {
      const curId = id++;
      const handler = evt => {
        const msg = JSON.parse(evt.data);
        if (msg.id === curId) {
          ws.removeEventListener('message', handler);
          if (msg.error) reject(new Error(msg.error.message));
          else resolve(msg.result);
        }
      };
      ws.addEventListener('message', handler);
      ws.send(JSON.stringify({ id: curId, method, params }));
    });

    const consoleErrors = [];
    ws.addEventListener('message', evt => {
      try {
        const msg = JSON.parse(evt.data);
        if (msg.method === 'Runtime.consoleAPICalled' && msg.params.type === 'error') {
          consoleErrors.push(msg.params.args.map(a => a.value || a.description).join(' '));
        }
      } catch(e) {}
    });

    await new Promise(r => ws.onopen = r);
    await send('Page.enable');
    await send('Runtime.enable');
    await send('DOM.enable');

    await send('Page.navigate', { url: `http://127.0.0.1:${PORT}/index.html` });
    await new Promise(r => setTimeout(r, 2000));
    await send('Runtime.evaluate', { expression: 'document.fonts ? document.fonts.ready : Promise.resolve()', awaitPromise: true });

    // Hide preview navbar and style inspector container to fill full viewport for realistic responsive testing
    await send('Runtime.evaluate', {
      expression: `(() => {
        const nav = document.querySelector('.preview-navbar');
        if (nav) nav.style.display = 'none';

        const modal = document.getElementById('screen-inspector-modal');
        const container = document.querySelector('.screen-inspector-container');
        const topbar = document.querySelector('.screen-inspector-topbar');

        if (modal) {
          modal.style.position = 'fixed';
          modal.style.top = '0';
          modal.style.left = '0';
          modal.style.width = '100vw';
          modal.style.height = '100vh';
          modal.style.overflowX = 'hidden';
          modal.style.overflowY = 'auto';
          modal.style.background = 'var(--voak-canvas)';
          modal.style.padding = '0';
        }
        if (topbar) topbar.style.display = 'none';
        if (container) {
          container.style.maxWidth = '100%';
          container.style.width = '100%';
          container.style.borderRadius = '0';
          container.style.boxShadow = 'none';
          container.style.border = 'none';
          container.style.margin = '0';
        }
      })()`
    });

    const results = {
      timestamp: new Date().toISOString(),
      summary: { total: 0, passed: 0, failed: 0 },
      publicPages: [],
      adminModules: []
    };

    log('======================================================================');
    log('PART 1: PUBLIC PAGES RESPONSIVE VERIFICATION (22 PAGES × 9 BREAKPOINTS)');
    log('======================================================================\n');

    for (let p = 1; p <= 22; p++) {
      const pageId = `PUB-${String(p).padStart(2, '0')}`;

      // Open page in inspector
      await send('Runtime.evaluate', { expression: `inspectPage('${pageId}')` });
      await new Promise(r => setTimeout(r, 200));

      // Get page metadata & verify marker
      const meta = await send('Runtime.evaluate', {
        expression: `(() => {
          const title = document.getElementById('inspector-title')?.textContent || '';
          const route = document.getElementById('inspector-route')?.textContent || '';
          const body = document.getElementById('screen-mockup-body');
          return {
            title,
            route,
            hasContent: !!body && body.innerHTML.trim().length > 50
          };
        })()`,
        returnByValue: true
      });

      const { title, route, hasContent } = meta.result.value;

      log(`Testing Public Page [${pageId}] - ${title} (${route})`);

      for (const bp of PUBLIC_BREAKPOINTS) {
        results.summary.total++;

        await send('Emulation.setDeviceMetricsOverride', {
          width: bp.width,
          height: bp.height,
          deviceScaleFactor: 1,
          mobile: false
        });
        await new Promise(r => setTimeout(r, 120));

        // Evaluate overflow and markers
        const check = await send('Runtime.evaluate', {
          expression: `(() => {
            const body = document.getElementById('screen-mockup-body');
            const innerW = window.innerWidth;
            const scrollW = Math.max(document.documentElement.scrollWidth, document.body.scrollWidth);
            const bodyScrollW = body ? body.scrollWidth : 0;
            const maxW = Math.max(scrollW, bodyScrollW);
            const overflowPx = Math.max(0, maxW - innerW);
            const isOverflow = overflowPx > 1.5;

            // Find overflowing elements if any
            const overflowing = [];
            if (isOverflow && body) {
              const all = body.querySelectorAll('*');
              for (let el of all) {
                const rect = el.getBoundingClientRect();
                if (rect.right > innerW + 2) {
                  overflowing.push(el.tagName.toLowerCase() + (el.className ? '.' + el.className.split(' ')[0] : ''));
                  if (overflowing.length >= 3) break;
                }
              }
            }

            return {
              innerWidth: innerW,
              scrollWidth: maxW,
              isOverflow,
              overflowing
            };
          })()`,
          returnByValue: true
        });

        const chk = check.result.value;
        const testErrors = [...consoleErrors];
        consoleErrors.length = 0; // reset

        const passed = hasContent && !chk.isOverflow;
        if (passed) results.summary.passed++;
        else results.summary.failed++;

        const entry = {
          id: pageId,
          type: 'PUBLIC_PAGE',
          title,
          route,
          viewport: { width: bp.width, height: bp.height, category: bp.category },
          markerVerified: hasContent,
          innerWidth: chk.innerWidth,
          scrollWidth: chk.scrollWidth,
          overflow: chk.isOverflow,
          overflowingElements: chk.overflowing,
          consoleErrors: testErrors,
          status: passed ? 'PASS' : 'FAIL'
        };

        results.publicPages.push(entry);

        const statusIcon = passed ? 'PASS' : 'FAIL';
        log(`  [${statusIcon}] ${bp.width}px (${bp.category}): innerWidth=${chk.innerWidth}, scrollWidth=${chk.scrollWidth}, overflow=${chk.isOverflow}`);
      }
      log('');
    }

    log('======================================================================');
    log('PART 2: ADMIN MODULES RESPONSIVE VERIFICATION (19 MODULES × 3 BREAKPOINTS)');
    log('======================================================================\n');

    // Switch to admin portal view
    await send('Runtime.evaluate', {
      expression: `(() => {
        closeScreenInspector();
        switchTab('admin-portal');
        simulateRole('ROLE_SUPER_ADMIN');
      })()`
    });
    await new Promise(r => setTimeout(r, 400));

    for (let m = 1; m <= 19; m++) {
      const modId = `ADM-${String(m).padStart(2, '0')}`;

      await send('Runtime.evaluate', { expression: `showAdminModule('${modId}')` });
      await new Promise(r => setTimeout(r, 200));

      const meta = await send('Runtime.evaluate', {
        expression: `(() => {
          const mod = ADMIN_MODULES['${modId}'];
          const ws = document.getElementById('admin-module-display');
          return {
            title: mod ? mod.title : '${modId}',
            hasContent: !!ws && ws.innerHTML.trim().length > 50
          };
        })()`,
        returnByValue: true
      });

      const { title, hasContent } = meta.result.value;

      log(`Testing Admin Module [${modId}] - ${title}`);

      for (const bp of ADMIN_BREAKPOINTS) {
        results.summary.total++;

        await send('Emulation.setDeviceMetricsOverride', {
          width: bp.width,
          height: bp.height,
          deviceScaleFactor: 1,
          mobile: false
        });
        await new Promise(r => setTimeout(r, 150));

        const check = await send('Runtime.evaluate', {
          expression: `(() => {
            const innerW = window.innerWidth;
            const scrollW = Math.max(document.documentElement.scrollWidth, document.body.scrollWidth);
            const overflowPx = Math.max(0, scrollW - innerW);
            const isOverflow = overflowPx > 1.5;

            const overflowing = [];
            if (isOverflow) {
              const all = document.querySelectorAll('*');
              for (let el of all) {
                const rect = el.getBoundingClientRect();
                if (rect.right > innerW + 2) {
                  overflowing.push(el.tagName.toLowerCase() + (el.className ? '.' + el.className.split(' ')[0] : ''));
                  if (overflowing.length >= 3) break;
                }
              }
            }

            return {
              innerWidth: innerW,
              scrollWidth: scrollW,
              isOverflow,
              overflowing
            };
          })()`,
          returnByValue: true
        });

        const chk = check.result.value;
        const testErrors = [...consoleErrors];
        consoleErrors.length = 0;

        const passed = hasContent && !chk.isOverflow;
        if (passed) results.summary.passed++;
        else results.summary.failed++;

        const entry = {
          id: modId,
          type: 'ADMIN_MODULE',
          title,
          route: `/admin?module=${modId}`,
          viewport: { width: bp.width, height: bp.height, category: bp.category },
          markerVerified: hasContent,
          innerWidth: chk.innerWidth,
          scrollWidth: chk.scrollWidth,
          overflow: chk.isOverflow,
          overflowingElements: chk.overflowing,
          consoleErrors: testErrors,
          status: passed ? 'PASS' : 'FAIL'
        };

        results.adminModules.push(entry);

        const statusIcon = passed ? 'PASS' : 'FAIL';
        log(`  [${statusIcon}] ${bp.width}px (${bp.category}): innerWidth=${chk.innerWidth}, scrollWidth=${chk.scrollWidth}, overflow=${chk.isOverflow}`);
      }
      log('');
    }

    log('======================================================================');
    log('EXPANDED RESPONSIVE TEST EXECUTION SUMMARY');
    log('======================================================================');
    log(`Total Verifications: ${results.summary.total}`);
    log(`Passed:              ${results.summary.passed}`);
    log(`Failed:              ${results.summary.failed}`);
    log(`Pass Rate:           ${((results.summary.passed / results.summary.total) * 100).toFixed(1)}%`);
    log('======================================================================\n');

    // Write outputs
    fs.writeFileSync(path.join(RESULTS_DIR, 'phase-03-responsive-results.json'), JSON.stringify(results, null, 2));
    fs.writeFileSync(path.join(RESULTS_DIR, 'phase-03-test-output.txt'), outputLog.join('\n'));

    log(`Results JSON written to: tests/results/phase-03-responsive-results.json`);
    log(`Execution log written to: tests/results/phase-03-test-output.txt`);

    ws.close();
    browserProcess.kill();
    server.close();
    process.exit(results.summary.failed === 0 ? 0 : 1);
  } catch (err) {
    console.error('Fatal error during expanded responsive tests:', err);
    browserProcess.kill();
    server.close();
    process.exit(1);
  }
}
