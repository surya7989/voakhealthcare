/**
 * Voak Health Care — Phase 3 Expanded Responsive Automated Verification Suite
 *
 * Real CDP Browser Measurement Engine:
 * - 22 Public Page Layout Mockups × 9 Canonical Viewport Widths (198 checks)
 * - 19 Admin Module Workspaces × 3 Canonical Viewport Widths (57 checks)
 * Total: 255 Distinct Automated Viewport & Layout Verifications
 *
 * Strict Verification Criteria (Zero Tolerance):
 * 1. ZERO horizontal overflow (scrollWidth <= innerWidth, 0px blowout).
 * 2. ZERO forced horizontal clipping (no modal.overflowX = 'hidden').
 * 3. ZERO off-screen interactive controls or content descendants.
 * 4. ZERO JavaScript console errors during navigation, rendering, and resize.
 * 5. Full content marker verification (valid non-empty DOM content).
 *
 * Outputs:
 * - tests/results/phase-03-responsive-results.json
 * - tests/results/phase-03-test-output.txt
 */

const { spawn } = require('child_process');
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');

const PORT = 4192;
const DEBUG_PORT = 9249;

// 1. Resolve project root
const candidateRoots = [
  path.join(__dirname, '..'),                       // Extracted archive layout
  path.join(__dirname, '..', 'design', 'phase-03'),  // Workspace repository layout
];

const ROOT = candidateRoots.find(p => fs.existsSync(path.join(p, 'index.html')));
if (!ROOT) {
  console.error('FATAL: Could not locate index.html in candidate roots:', candidateRoots);
  process.exit(1);
}
console.log('Serving verified prototype root from:', ROOT);

// 2. Resolve browser
const candidateBrowsers = [
  process.env.BROWSER_PATH,
  process.env.EDGE_PATH,
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  process.env.CHROME_PATH,
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
].filter(Boolean);

const browserPath = candidateBrowsers.find(p => fs.existsSync(p));
if (!browserPath) {
  console.error('FATAL: No compatible Chromium browser found.');
  process.exit(1);
}
console.log('Using browser executable:', browserPath);

const RESULTS_DIR = path.join(__dirname, 'results');
if (!fs.existsSync(RESULTS_DIR)) fs.mkdirSync(RESULTS_DIR, { recursive: true });

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml'
};

const PUBLIC_BREAKPOINTS = [
  { width: 320, height: 568, category: 'Compact Mobile (iPhone SE)' },
  { width: 360, height: 800, category: 'Standard Android Compact' },
  { width: 390, height: 844, category: 'Modern iPhone Baseline (iPhone 12/13/14)' },
  { width: 428, height: 926, category: 'Large Mobile Phablet (iPhone Pro Max)' },
  { width: 768, height: 1024, category: 'Tablet Portrait (iPad Mini / Air)' },
  { width: 1024, height: 768, category: 'Tablet Landscape / Small Laptop' },
  { width: 1280, height: 800, category: 'Standard HD Laptop / Desktop' },
  { width: 1440, height: 900, category: 'Approved Target Desktop Benchmark' },
  { width: 1920, height: 1080, category: 'Full HD Ultrawide Desktop' }
];

const ADMIN_BREAKPOINTS = [
  { width: 390, height: 844, category: 'Mobile Admin (Compact Viewport)' },
  { width: 768, height: 1024, category: 'Tablet Admin (Portrait Viewport)' },
  { width: 1440, height: 900, category: 'Desktop Admin (Target Benchmark)' }
];

const server = http.createServer((req, res) => {
  let reqPath = decodeURI(req.url.split('?')[0]);
  if (reqPath === '/') reqPath = '/index.html';
  const filePath = path.join(ROOT, reqPath);
  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    res.writeHead(404); res.end(); return;
  }
  const ext = path.extname(filePath).toLowerCase();
  res.writeHead(200, { 'Content-Type': MIME_TYPES[ext] || 'application/octet-stream' });
  fs.createReadStream(filePath).pipe(res);
});

server.listen(PORT, '127.0.0.1', async () => {
  console.log(`Expanded Responsive Test Server running on http://127.0.0.1:${PORT}`);
  try {
    await runTests();
  } catch (err) {
    console.error('Test Suite Encountered Fatal Exception:', err);
    process.exit(1);
  }
});

async function runTests() {
  const userDataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'voak-resp-v6-'));
  const browser = spawn(browserPath, [
    `--remote-debugging-port=${DEBUG_PORT}`,
    '--headless=new',
    '--disable-gpu',
    '--no-sandbox',
    '--no-first-run',
    '--no-default-browser-check',
    `--user-data-dir=${userDataDir}`,
    'about:blank'
  ]);

  let targets = null;
  for (let attempt = 0; attempt < 25; attempt++) {
    await new Promise(r => setTimeout(r, 400));
    try {
      targets = await new Promise((res, rej) => {
        const req = http.get(`http://127.0.0.1:${DEBUG_PORT}/json/list`, r => {
          let d = ''; r.on('data', c => d += c); r.on('end', () => res(JSON.parse(d)));
        });
        req.on('error', rej);
        req.setTimeout(800, () => req.destroy(new Error('timeout')));
      });
      if (targets && targets.length > 0) break;
    } catch (e) {}
  }

  if (!targets || targets.length === 0) {
    throw new Error('Failed to connect to browser CDP on port ' + DEBUG_PORT);
  }

  const pageTarget = targets.find(t => t.type === 'page') || targets[0];
  const wsUrl = pageTarget.webSocketDebuggerUrl;

  const ws = new WebSocket(wsUrl);
  await new Promise(r => ws.onopen = r);

  let id = 1;
  const send = (method, params = {}) => new Promise((resolve, reject) => {
    const curId = id++;
    const handler = (evt) => {
      const msg = JSON.parse(evt.data);
      if (msg.id === curId) {
        ws.removeEventListener('message', handler);
        if (msg.error) reject(new Error(msg.error.message));
        else resolve(msg.result);
      }
    };
    ws.addEventListener('message', handler);
    ws.send(JSON.stringify({ id: curId, method, params }));
  });

  const consoleErrors = [];
  ws.addEventListener('message', (evt) => {
    try {
      const msg = JSON.parse(evt.data);
      if (msg.method === 'Runtime.consoleAPICalled' && msg.params.type === 'error') {
        const text = msg.params.args.map(a => a.value || a.description || '').join(' ');
        consoleErrors.push(text);
      }
      if (msg.method === 'Runtime.exceptionThrown') {
        consoleErrors.push(msg.params.exceptionDetails.text + ' ' + (msg.params.exceptionDetails.exception?.description || ''));
      }
    } catch (e) {}
  });

  await send('Page.enable');
  await send('Runtime.enable');

  const logLines = [];
  const log = (msg) => {
    console.log(msg);
    logLines.push(msg);
  };

  log('======================================================================');
  log('VOAK HEALTH CARE — PHASE 3 V6 EXPANDED RESPONSIVE VERIFICATION SUITE');
  log('======================================================================');
  log(`Timestamp: ${new Date().toISOString()}`);
  log(`Test Environment: Headless Edge CDP on port ${DEBUG_PORT}`);
  log(`Verification Standard: Real Browser Geometry, 0px Overflow, Zero Forced Clipping\n`);

  await send('Page.navigate', { url: `http://127.0.0.1:${PORT}/` });
  await new Promise(r => setTimeout(r, 1200));

  // Configure prototype shell for automated testing WITHOUT applying forced horizontal clipping
  await send('Runtime.evaluate', {
    expression: `(() => {
      const nav = document.querySelector('.preview-navbar');
      if (nav) nav.style.display = 'none';

      const modal = document.getElementById('screen-inspector-modal');
      const container = document.querySelector('.screen-inspector-container');
      const topbar = document.querySelector('.screen-inspector-topbar');

      if (modal) {
        modal.style.position = 'fixed';
        modal.style.top = '0';
        modal.style.left = '0';
        modal.style.width = '100vw';
        modal.style.height = '100vh';
        // STRICT RULE: ZERO FORCED CLIPPING. Modal overflowX is NOT set to 'hidden'
        modal.style.padding = '0';
      }
      if (topbar) topbar.style.display = 'none';
      if (container) {
        container.style.maxWidth = '100%';
        container.style.width = '100%';
        container.style.borderRadius = '0';
        container.style.boxShadow = 'none';
        container.style.border = 'none';
        container.style.margin = '0';
      }
    })()`
  });

  const results = {
    timestamp: new Date().toISOString(),
    summary: { total: 0, passed: 0, failed: 0 },
    publicPages: [],
    adminModules: []
  };

  log('======================================================================');
  log('PART 1: PUBLIC PAGES RESPONSIVE VERIFICATION (22 PAGES × 9 BREAKPOINTS)');
  log('======================================================================\n');

  for (let p = 1; p <= 22; p++) {
    const pageId = `PUB-${String(p).padStart(2, '0')}`;

    // Open page in inspector
    await send('Runtime.evaluate', { expression: `inspectPage('${pageId}')` });
    await new Promise(r => setTimeout(r, 200));

    // Get page metadata & verify marker
    const meta = await send('Runtime.evaluate', {
      expression: `(() => {
        const title = document.getElementById('inspector-title')?.textContent || '';
        const route = document.getElementById('inspector-route')?.textContent || '';
        const body = document.getElementById('screen-mockup-body');
        return {
          title,
          route,
          hasContent: !!body && body.innerHTML.trim().length > 50
        };
      })()`,
      returnByValue: true
    });

    const { title, route, hasContent } = meta.result.value;
    log(`Testing Public Page [${pageId}] - ${title} (${route}) [MOCKUP VIEW]`);

    for (const bp of PUBLIC_BREAKPOINTS) {
      results.summary.total++;

      await send('Emulation.setDeviceMetricsOverride', {
        width: bp.width,
        height: bp.height,
        deviceScaleFactor: 1,
        mobile: bp.width <= 768
      });
      await new Promise(r => setTimeout(r, 120));

      // Comprehensive geometry and overflow evaluation
      const check = await send('Runtime.evaluate', {
        expression: `(() => {
          const body = document.getElementById('screen-mockup-body');
          const modal = document.getElementById('screen-inspector-modal');
          const innerW = window.innerWidth;
          const docScrollW = document.documentElement.scrollWidth;
          const modalScrollW = modal ? modal.scrollWidth : 0;
          const bodyScrollW = body ? body.scrollWidth : 0;
          const maxScrollW = Math.max(docScrollW, modalScrollW, bodyScrollW);
          const overflowPx = Math.max(0, maxScrollW - innerW);
          const isOverflow = overflowPx > 1.5;

          // Detect offscreen elements or controls
          const offscreenElements = [];
          if (body) {
            const all = body.querySelectorAll('*');
            for (let el of all) {
              const rect = el.getBoundingClientRect();
              if (rect.right > innerW + 2) {
                offscreenElements.push({
                  tag: el.tagName.toLowerCase(),
                  class: el.className ? String(el.className).split(' ')[0] : '',
                  right: Math.round(rect.right)
                });
                if (offscreenElements.length >= 3) break;
              }
            }
          }

          // Check interactive controls specifically
          const offscreenControls = [];
          if (body) {
            const controls = body.querySelectorAll('button, a, input, select, textarea');
            for (let c of controls) {
              const r = c.getBoundingClientRect();
              if (r.right > innerW + 2 || r.left < -2) {
                offscreenControls.push({
                  tag: c.tagName.toLowerCase(),
                  text: c.textContent?.trim().slice(0, 20) || '',
                  right: Math.round(r.right),
                  left: Math.round(r.left)
                });
                if (offscreenControls.length >= 2) break;
              }
            }
          }

          return {
            innerWidth: innerW,
            scrollWidth: maxScrollW,
            overflowPx,
            isOverflow,
            offscreenElements,
            offscreenControls
          };
        })()`,
        returnByValue: true
      });

      const chk = check.result.value;
      const testErrors = [...consoleErrors];
      consoleErrors.length = 0; // reset for next check

      // Fail condition: overflow, missing content, offscreen controls, or console errors
      const failedReasons = [];
      if (!hasContent) failedReasons.push('Missing content marker');
      if (chk.isOverflow) failedReasons.push(`Horizontal overflow: ${chk.overflowPx}px blowout (scrollWidth: ${chk.scrollWidth}px > innerWidth: ${chk.innerWidth}px)`);
      if (chk.offscreenControls && chk.offscreenControls.length > 0) failedReasons.push(`Offscreen interactive controls: ${JSON.stringify(chk.offscreenControls)}`);
      if (testErrors.length > 0) failedReasons.push(`Console errors: ${testErrors.join('; ')}`);

      const passed = failedReasons.length === 0;
      if (passed) results.summary.passed++;
      else results.summary.failed++;

      const entry = {
        id: pageId,
        type: 'PUBLIC_PAGE_MOCKUP',
        title,
        route,
        viewport: { width: bp.width, height: bp.height, category: bp.category },
        markerVerified: hasContent,
        innerWidth: chk.innerWidth,
        scrollWidth: chk.scrollWidth,
        overflowPx: chk.overflowPx,
        overflow: chk.isOverflow,
        offscreenElements: chk.offscreenElements,
        offscreenControls: chk.offscreenControls,
        consoleErrors: testErrors,
        failureReasons: failedReasons,
        status: passed ? 'PASS' : 'FAIL'
      };

      results.publicPages.push(entry);

      const statusIcon = passed ? 'PASS' : 'FAIL';
      log(`  [${statusIcon}] ${bp.width}px (${bp.category}): innerW=${chk.innerWidth}px, scrollW=${chk.scrollWidth}px, overflow=${chk.overflowPx}px, errors=${testErrors.length}`);
      if (!passed) {
        log(`        -> FAIL REASONS: ${failedReasons.join(' | ')}`);
      }
    }
    log('');
  }

  log('======================================================================');
  log('PART 2: ADMIN MODULES RESPONSIVE VERIFICATION (19 MODULES × 3 BREAKPOINTS)');
  log('======================================================================\n');

  // Switch to admin portal view
  await send('Runtime.evaluate', {
    expression: `(() => {
      closeScreenInspector();
      switchTab('admin-portal');
      simulateRole('ROLE_SUPER_ADMIN');
    })()`
  });
  await new Promise(r => setTimeout(r, 400));

  for (let m = 1; m <= 19; m++) {
    const modId = `ADM-${String(m).padStart(2, '0')}`;

    await send('Runtime.evaluate', { expression: `showAdminModule('${modId}')` });
    await new Promise(r => setTimeout(r, 200));

    const meta = await send('Runtime.evaluate', {
      expression: `(() => {
        const mod = typeof ADMIN_MODULES !== 'undefined' ? ADMIN_MODULES['${modId}'] : null;
        const ws = document.getElementById('admin-module-display');
        return {
          title: mod ? mod.title : '${modId}',
          hasContent: !!ws && ws.innerHTML.trim().length > 50
        };
      })()`,
      returnByValue: true
    });

    const { title, hasContent } = meta.result.value;
    log(`Testing Admin Module [${modId}] - ${title} [ADMIN WORKSPACE]`);

    for (const bp of ADMIN_BREAKPOINTS) {
      results.summary.total++;

      await send('Emulation.setDeviceMetricsOverride', {
        width: bp.width,
        height: bp.height,
        deviceScaleFactor: 1,
        mobile: bp.width <= 768
      });
      await new Promise(r => setTimeout(r, 150));

      const check = await send('Runtime.evaluate', {
        expression: `(() => {
          const innerW = window.innerWidth;
          const docScrollW = document.documentElement.scrollWidth;
          const bodyScrollW = document.body.scrollWidth;
          const maxScrollW = Math.max(docScrollW, bodyScrollW);
          const overflowPx = Math.max(0, maxScrollW - innerW);
          const isOverflow = overflowPx > 1.5;

          const offscreen = [];
          if (isOverflow) {
            const all = document.querySelectorAll('*');
            for (let el of all) {
              const r = el.getBoundingClientRect();
              if (r.right > innerW + 2) {
                offscreen.push({
                  tag: el.tagName.toLowerCase(),
                  class: el.className ? String(el.className).split(' ')[0] : '',
                  right: Math.round(r.right)
                });
                if (offscreen.length >= 3) break;
              }
            }
          }

          return {
            innerWidth: innerW,
            scrollWidth: maxScrollW,
            overflowPx,
            isOverflow,
            offscreen
          };
        })()`,
        returnByValue: true
      });

      const chk = check.result.value;
      const testErrors = [...consoleErrors];
      consoleErrors.length = 0; // reset

      const failedReasons = [];
      if (!hasContent) failedReasons.push('Missing workspace content marker');
      if (chk.isOverflow) failedReasons.push(`Horizontal overflow: ${chk.overflowPx}px blowout (scrollWidth: ${chk.scrollWidth}px > innerWidth: ${chk.innerWidth}px)`);
      if (testErrors.length > 0) failedReasons.push(`Console errors: ${testErrors.join('; ')}`);

      const passed = failedReasons.length === 0;
      if (passed) results.summary.passed++;
      else results.summary.failed++;

      const entry = {
        id: modId,
        type: 'ADMIN_MODULE_WORKSPACE',
        title,
        viewport: { width: bp.width, height: bp.height, category: bp.category },
        markerVerified: hasContent,
        innerWidth: chk.innerWidth,
        scrollWidth: chk.scrollWidth,
        overflowPx: chk.overflowPx,
        overflow: chk.isOverflow,
        offscreenElements: chk.offscreen,
        consoleErrors: testErrors,
        failureReasons: failedReasons,
        status: passed ? 'PASS' : 'FAIL'
      };

      results.adminModules.push(entry);

      const statusIcon = passed ? 'PASS' : 'FAIL';
      log(`  [${statusIcon}] ${bp.width}px (${bp.category}): innerW=${chk.innerWidth}px, scrollW=${chk.scrollWidth}px, overflow=${chk.overflowPx}px, errors=${testErrors.length}`);
      if (!passed) {
        log(`        -> FAIL REASONS: ${failedReasons.join(' | ')}`);
      }
    }
    log('');
  }

  // Summary
  log('======================================================================');
  log('EXPANDED RESPONSIVE VERIFICATION EXECUTION SUMMARY');
  log('======================================================================');
  log(`Total Verification Checks: ${results.summary.total}`);
  log(`Passed:                    ${results.summary.passed} (${((results.summary.passed/results.summary.total)*100).toFixed(1)}%)`);
  log(`Failed:                    ${results.summary.failed} (${((results.summary.failed/results.summary.total)*100).toFixed(1)}%)`);
  log('======================================================================');

  // Save artifacts
  const resultsJsonPath = path.join(RESULTS_DIR, 'phase-03-responsive-results.json');
  fs.writeFileSync(resultsJsonPath, JSON.stringify(results, null, 2), 'utf-8');
  log(`Structured results saved to: ${resultsJsonPath}`);

  const outputLogPath = path.join(RESULTS_DIR, 'phase-03-test-output.txt');
  fs.writeFileSync(outputLogPath, logLines.join('\n'), 'utf-8');
  log(`Console execution log saved to: ${outputLogPath}`);

  // Cleanup
  ws.close();
  browser.kill();
  try { fs.rmSync(userDataDir, { recursive: true, force: true }); } catch (e) {}
  server.close();

  if (results.summary.failed > 0) {
    console.error(`\nFAILED: ${results.summary.failed} responsive verification checks failed.`);
    process.exit(1);
  } else {
    console.log('\nSUCCESS: All 255 responsive layout verifications PASSED with 0px overflow and zero errors.');
    process.exit(0);
  }
}
