#!/usr/bin/env python3
"""
Voak Health Care — Phase 3 V6 Automated Screenshot Telemetry & Verification Engine

Measures exact physical PNG IHDR dimensions, file size, and SHA-256 hash directly
from disk files for all 50 required design review screenshots:
- 9 Primary Root Screenshots
- 19 Admin Module Workspaces
- 22 Public Page Mockups

Strict Verification:
1. Every file must exist and be readable.
2. Must have valid PNG magic signature (\x89PNG\r\n\x1a\n).
3. IHDR width and height are extracted directly from the PNG header chunks.
4. Telemetry is saved to tests/screenshot_metrics.json.
5. Re-verified against disk: 0 discrepancies required.
6. Exit non-zero if count != 50 or any mismatch detected.
"""

import os
import sys
import json
import struct
import hashlib

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCREENSHOT_DIR = os.path.join(BASE_DIR, 'design', 'phase-03', 'screenshots')
METRICS_OUTPUT = os.path.join(BASE_DIR, 'tests', 'screenshot_metrics.json')

EXPECTED_FILES = [
    # 9 Primary Screenshots
    "01_desktop_homepage.png",
    "02_mobile_homepage_390px.png",
    "03_tablet_homepage_768px.png",
    "04_public_pages_gallery.png",
    "05_admin_dashboard.png",
    "06_component_system.png",
    "07_approved_reference_comparison.png",
    "08_proposal_wizard_modal.png",
    "09_simulated_403_access_denied.png",
]

# 19 Admin Modules
for i in range(1, 20):
    EXPECTED_FILES.append(f"admin_modules/admin_adm-{i:02d}_preview.png")

# 22 Public Pages
for i in range(1, 23):
    EXPECTED_FILES.append(f"public_pages/page_pub-{i:02d}_preview.png")

def parse_png(file_path):
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Missing screenshot file: {file_path}")
    
    with open(file_path, 'rb') as f:
        data = f.read()

    size_bytes = len(data)
    if size_bytes < 24:
        raise ValueError(f"File too small to be valid PNG: {file_path}")

    # Check PNG signature
    png_sig = b'\x89PNG\r\n\x1a\n'
    if data[:8] != png_sig:
        raise ValueError(f"Invalid PNG signature for file: {file_path}")

    # Parse IHDR (chunk length 13, chunk type IHDR)
    ihdr_len, chunk_type = struct.unpack('>I4s', data[8:16])
    if chunk_type != b'IHDR' or ihdr_len != 13:
        raise ValueError(f"Missing or corrupted IHDR chunk in {file_path}")

    width, height = struct.unpack('>II', data[16:24])
    sha256 = hashlib.sha256(data).hexdigest()

    return {
        "width": width,
        "height": height,
        "sizeBytes": size_bytes,
        "sizeKb": f"{size_bytes / 1024:.1f}",
        "sha256": sha256
    }

def main():
    print("=" * 78)
    print("VOAK HEALTH CARE — PHASE 3 V6 SCREENSHOT TELEMETRY GENERATOR & VERIFIER")
    print("=" * 78)
    print(f"Target Screenshot Directory: {SCREENSHOT_DIR}")
    print(f"Metrics Output Destination:   {METRICS_OUTPUT}\n")

    if not os.path.exists(SCREENSHOT_DIR):
        print(f"FATAL: Screenshot directory does not exist: {SCREENSHOT_DIR}")
        sys.exit(1)

    metrics = {}
    errors = []

    print(f"{'#':<3} {'Screenshot Relative Path':<42} {'IHDR (W x H)':<16} {'Size (KB)':<10} {'Status'}")
    print("-" * 78)

    for idx, rel_path in enumerate(EXPECTED_FILES, 1):
        full_path = os.path.join(SCREENSHOT_DIR, rel_path.replace('/', os.sep))
        try:
            info = parse_png(full_path)
            metrics[rel_path] = info
            dim_str = f"{info['width']} x {info['height']}"
            print(f"{idx:<3} {rel_path:<42} {dim_str:<16} {info['sizeKb']:<10} PASS")
        except Exception as e:
            errors.append(f"{rel_path}: {str(e)}")
            print(f"{idx:<3} {rel_path:<42} {'ERROR':<16} {'-':<10} FAIL ({str(e)})")

    total_count = len(metrics)
    expected_count = len(EXPECTED_FILES)

    print("-" * 78)
    print(f"Total Expected: {expected_count}")
    print(f"Total Measured: {total_count}")
    print(f"Errors Found:   {len(errors)}")

    if len(errors) > 0 or total_count != expected_count:
        print("\nFATAL: Verification failed with errors:")
        for err in errors:
            print(f"  - {err}")
        sys.exit(1)

    # Save to tests/screenshot_metrics.json
    os.makedirs(os.path.dirname(METRICS_OUTPUT), exist_ok=True)
    with open(METRICS_OUTPUT, 'w', encoding='utf-8') as f:
        json.dump(metrics, f, indent=2)
    print(f"\n[OK] screenshot_metrics.json successfully written ({total_count} verified entries)")

    # Independent round-trip re-verification
    print("\n--- Performing Independent Re-Verification from JSON Manifest ---")
    with open(METRICS_OUTPUT, 'r', encoding='utf-8') as f:
        loaded = json.load(f)

    discrepancies = 0
    for rel_path, expected_entry in loaded.items():
        full_path = os.path.join(SCREENSHOT_DIR, rel_path.replace('/', os.sep))
        re_info = parse_png(full_path)
        if (re_info['width'] != expected_entry['width'] or
            re_info['height'] != expected_entry['height'] or
            re_info['sizeBytes'] != expected_entry['sizeBytes'] or
            re_info['sha256'] != expected_entry['sha256']):
            print(f"DISCREPANCY in {rel_path}:")
            print(f"  Recorded: {expected_entry}")
            print(f"  Actual:   {re_info}")
            discrepancies += 1

    print(f"Total Manifest Discrepancies: {discrepancies}")
    if discrepancies > 0:
        print("FATAL: Discrepancies found between manifest and actual disk files!")
        sys.exit(1)

    print("=" * 78)
    print("SUCCESS: ALL 50 SCREENSHOTS VERIFIED WITH EXACT DISK IHDR TELEMETRY (0 DISCREPANCIES)")
    print("=" * 78)
    sys.exit(0)

if __name__ == '__main__':
    main()
