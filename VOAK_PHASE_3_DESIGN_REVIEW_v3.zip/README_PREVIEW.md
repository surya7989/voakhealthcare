# Voak Health Care — Phase 3 UI/UX Design System Review Package
## Reconciled Master Visual Prototype & Design Guidelines

**Package:** `VOAK_PHASE_3_DESIGN_REVIEW.zip`  
**Phase:** Phase 3 of 31 — Professional UI/UX Design (Reconciled Baseline)  
**Date:** 2026-10-16  
**Status:** Complete & Reconciled — Ready for Client Visual Review  

---

### 1. How to Run & Preview the Prototype

You can inspect the prototype in either of two simple ways:

#### Option A: Lightweight Local HTTP Server (Recommended)
1. Ensure Node.js is installed.
2. Open a terminal in the extracted directory.
3. Run:
   ```bash
   node serve.js
   ```
4. Open your web browser and navigate to:
   ```
   http://127.0.0.1:4173/
   ```

#### Option B: Direct Browser Inspection
- Simply double-click `index.html` in your file explorer to open it directly in Google Chrome, Microsoft Edge, Mozilla Firefox, or Safari. All styles, fonts, and scripts will load immediately.

---

### 2. Prototype Features & Key Inspection Views

Use the top navigation bar inside the prototype to switch between master views:

1. **Desktop Homepage (`#hero`):**
   - Faithful recreation of the approved Image 2 aesthetic benchmark.
   - Soft lavender canvas background (`#F2F0F8`).
   - White rounded main page shell (`border-radius: 36px`).
   - Editorial serif headlines (`Fraunces 64px`, `#252B5E`).
   - Healthcare professional portrait framed with pastel pink (`#EEAFD7`) and warm yellow (`#FBDC62`) collage shapes.
   - Three colorful feature cards (Pink, Yellow, Mint).
   - Asymmetric bento services grid and accessible corporate footer.

2. **Mobile Homepage (`#mobile`):**
   - Single-thumb vertical responsive composition.
   - Device frame simulator for testing 320px (iPhone SE compact), 360px (Android), 390px (iPhone baseline), and 428px (Pro Max).
   - Zero horizontal overflow, zero text clipping, accessible 48px touch targets.

3. **All 22 Public Pages (`#pages`):**
   - Summary cards displaying canonical requirement IDs (`FR-PUB-xxx`), routes (`/request-proposal`, `/faqs`), key sections, and primary CTAs.
   - Click **"Inspect Screen →"** on any page card to launch the **Full-Page Screen Inspector**, rendering a complete, full-scale high-fidelity mockup with page-specific hero, body sections, cards, and footer!

4. **All 19 Admin Modules (`#admin`):**
   - Deep slate-navy sidebar (`#0F172A`) containing all 19 canonical modules (`ADM-01` to `ADM-19`).
   - **DESIGN-ONLY RBAC SIMULATOR:** Click between the 5 canonical roles (`Super Admin`, `Website Admin`, `Content Editor`, `BD Manager`, `HR Manager`) to test live least-privilege boundary visual behaviors. Unauthorized module access triggers a **SIMULATED 403 ACCESS DENIED** card (authentic HTTP 403 status responses will be enforced by Phase 6 PHP middleware).
   - Every module features realistic data tables, forms, and status chips prominently watermarked `[DEMO DATA ONLY — SIMULATED RECORDS]`.

5. **Component & Design Token System (`#components`):**
   - Locked color palette swatches with measured mathematical contrast ratios (WCAG 2.2 AA / AAA ratings).
   - Typography hierarchy scale (`Fraunces` and `Plus Jakarta Sans`).
   - Interactive button states, chips, dropzones, and status indicators.

6. **Approved References Comparison (`#refs`):**
   - Side-by-side visual inspection comparing the user-approved Image 2 homepage benchmark and the approved Admin portal reference against the Voak design system.

7. **Interactive Proposal Wizard Modal (FORM-PUB-03):**
   - Click "Request Proposal" from any header or card to launch the 4-step RFP wizard.
   - Scope organization profile, clinical services, procurement timeline, and tender document upload with instant validation.

---

### 3. Package File Structure

```
VOAK_PHASE_3_DESIGN_REVIEW/
├── index.html                           # Master navigable visual prototype shell
├── styles.css                           # Master design tokens & stylesheet
├── app.js                               # Prototype logic (22 public mockups, 19 admin modules, role simulator)
├── serve.js                             # Local HTTP preview server (port 4173)
├── README_PREVIEW.md                    # This preview guide
├── 18_PHASE_3_CORRECTION_AND_ACCEPTANCE_REPORT.md # Complete audit and reconciliation report
├── assets/
│   └── images/
│       ├── hero_doctor.jpg              # High-res healthcare professional portrait (1024x1024)
│       └── operations_manager.jpg       # Clinical operations coordinator portrait (1024x1024)
├── references/
│   ├── approved_homepage_reference_image_2.png # Approved Image 2 benchmark
│   └── approved_admin_reference_portal.png     # Approved Admin benchmark
└── screenshots/
    ├── 01_desktop_homepage.png          # Rendered desktop homepage (1440x1100)
    ├── 02_mobile_homepage_390px.png      # Rendered mobile homepage (420x900)
    ├── 03_tablet_homepage_768px.png      # Rendered tablet homepage (768x1024)
    ├── 04_public_pages_gallery.png       # Rendered public pages gallery (1440x1100)
    ├── 05_admin_dashboard.png            # Rendered admin dashboard with role simulator (1440x1000)
    ├── 06_approved_reference_comparison.png # Rendered reference comparison (1440x1000)
    └── 07_component_system.png           # Rendered component tokens (1440x1100)
```

---

### 4. Governance & Roadmap Status

- **Phase 0:** ACCEPTED
- **Phase 1:** ACCEPTED
- **Phase 2:** ACCEPTED
- **Phase 3:** RECONCILED & COMPLETE (Awaiting client visual approval)
- **Phase 4:** STRICTLY NOT AUTHORIZED (Halted before start)
- **Total Roadmap:** Exactly 32 phases (Phase 0 through Phase 31) preserved.
